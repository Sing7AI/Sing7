# Sing7 Project Setup
